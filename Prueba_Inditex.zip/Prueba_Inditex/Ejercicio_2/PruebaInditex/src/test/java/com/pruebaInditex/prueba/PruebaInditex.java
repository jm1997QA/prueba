package com.pruebaInditex.prueba;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;

public class PruebaInditex {
	private WebDriver driver;
	
	@Before
	public void setUp() throws Exception{
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
	}
	
	//4. Realizar un screenshot de la p�gina de la Wikipedia
	public String getDate() {
		DateFormat dateFormat = new SimpleDateFormat("dd-mm-yy");
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	@Rule
	public TestRule watcher = new TestWatcher() {
		@Override
		protected void failed(Throwable throwable, Description description) {
			File screenshotFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			try {
				FileUtils.copyFile(screenshotFile, new File("ERROR_"+description.getMethodName()+"_"+getDate()+".png"));
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		@Override
		protected void finished(Description description) {
			driver.close();
		}
	};
	
	@Test
	public void pruebaInditex() throws InterruptedException {
		Thread.sleep(1000);
		WebElement cookies = driver.findElement(By.xpath("//button//div[contains(text(),'Aceptar todo')]"));
		cookies.click();
		Thread.sleep(10000);
		
		//1. Buscar en Google la palabra �automatizaci�n�
		WebElement searchbox = driver.findElement(By.name("q"));
		searchbox.clear();
		searchbox.sendKeys("automatizaci�n");
		searchbox.submit();
		Thread.sleep(10000);
		
		//2. Buscar el link de la Wikipedia resultante 
		WebElement linkWikipedia = driver.findElement(By.xpath("//h3[contains(text(),'Automatizaci�n industrial')]"));
		linkWikipedia.click();
		Thread.sleep(10000);
		
		//3. Comprobar en qu� a�o se hizo el primer proceso autom�tico
		/* 1801 es el a�o en que se registra la primera patente de un proceso autom�tico */
		WebElement textElement = driver.findElement(By.xpath("//p[contains(text(),'1801')]"));
		Boolean texto = textElement.getText().contains("1801");
		System.out.println("�Coincide la fecha? "+ texto);
		Thread.sleep(10000);
		
		//4. Realizar un screenshot de la p�gina de la Wikipedia
		assertEquals("Esto provocar� un error", driver.getTitle());
	}
}
